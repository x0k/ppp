package classes.special_test;

class NoSuchFieldObject {
  int hasOwnProperty;
}
