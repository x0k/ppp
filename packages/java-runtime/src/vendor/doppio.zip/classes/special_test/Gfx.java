package classes.special_test;
import java.awt.Frame;
public class Gfx {
  public static void main(String[] args) {
    Frame f = new Frame("Hello GFX");
    f.setVisible(true);
  }
}
